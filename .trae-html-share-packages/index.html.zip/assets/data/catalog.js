﻿/* 由 catalog.json 生成，请勿手改；改 catalog.json 后用 build-catalog.ps1 重新生成 */
window.DM_CATALOG = {
  "site": {
    "name": "豆苗学堂",
    "full": "豆苗逐智 · 童享科技",
    "intro": "少儿 AI 与计算机公益科普",
    "org": "河海大学计算机与软件学院 · 南京",
    "ages": "6-12 岁",
    "privacy": "无需注册 · 不联网收集信息"
  },
  "modules": {
    "binary": {
      "key": "binary",
      "name": "二进制的秘密",
      "scene": "秦淮花灯",
      "ic": "lantern",
      "color": "var(--gold)",
      "dir": "binary",
      "level": "entry",
      "lessons": [
        { "file": "lesson-01.html", "title": "花灯的开关魔法", "stones": 3 },
        { "file": "lesson-02.html", "title": "用花灯数数", "stones": 3 },
        { "file": "lesson-03.html", "title": "字符变变变", "stones": 3 }
      ],
      "game": { "file": "game-lightbulb.html", "title": "花灯密码闯关", "stones": 3 },
      "quiz": { "file": "quiz.html", "title": "挑战测验", "stones": 3 }
    },
    "ai": {
      "key": "ai",
      "name": "AI 小课堂",
      "scene": "红山动物园",
      "ic": "robot",
      "color": "var(--accent)",
      "dir": "ai",
      "level": "entry",
      "lessons": [
        { "file": "lesson-01.html", "title": "身边的 AI", "stones": 2 },
        { "file": "lesson-02.html", "title": "机器学习：喂图片给电脑", "stones": 3 },
        { "file": "lesson-03.html", "title": "AI 也会犯错", "stones": 3 },
        { "file": "lesson-04.html", "title": "AI 能做与不能做", "stones": 2 }
      ],
      "game": { "file": "game-trainer.html", "title": "训练 AI 小助手", "stones": 3 },
      "quiz": { "file": "quiz.html", "title": "挑战测验", "stones": 3 }
    },
    "coding": {
      "key": "coding",
      "name": "编程初体验",
      "scene": "秦淮画舫",
      "ic": "boat",
      "color": "var(--green)",
      "dir": "coding",
      "level": "entry",
      "lessons": [
        { "file": "lesson-01.html", "title": "给画舫下指令", "stones": 3 },
        { "file": "lesson-02.html", "title": "一步一步来：顺序执行", "stones": 3 },
        { "file": "lesson-03.html", "title": "循环的威力", "stones": 3 }
      ],
      "game": { "file": "game-maze.html", "title": "画舫航线闯关", "stones": 3 },
      "quiz": { "file": "quiz.html", "title": "挑战测验", "stones": 3 }
    },
    "safety": {
      "key": "safety",
      "name": "城墙小卫士",
      "scene": "南京明城墙",
      "ic": "wall",
      "color": "var(--cyan)",
      "dir": "safety",
      "level": "entry",
      "lessons": [
        { "file": "lesson-01.html", "title": "网络是什么", "stones": 2 },
        { "file": "lesson-02.html", "title": "我的小秘密", "stones": 3 },
        { "file": "lesson-03.html", "title": "网上交友要小心", "stones": 2 },
        { "file": "lesson-04.html", "title": "遇到坏心思怎么办", "stones": 3 }
      ],
      "game": { "file": "game-shield.html", "title": "城墙情境闯关", "stones": 3 },
      "quiz": { "file": "quiz.html", "title": "挑战测验", "stones": 3 }
    },
    "terms": {
      "key": "terms",
      "name": "AI 术语解码",
      "scene": "金陵图书馆",
      "ic": "brain",
      "color": "var(--purple)",
      "dir": "ai-terms",
      "level": "advanced",
      "lessons": [
        { "file": "lesson-01.html", "title": "机器学习家族与神经网络", "stones": 3 },
        { "file": "lesson-02.html", "title": "大语言模型与提示词", "stones": 3 },
        { "file": "lesson-03.html", "title": "数据、幻觉与 AI 安全", "stones": 3 }
      ],
      "game": { "file": "game-match.html", "title": "术语挑战赛", "stones": 3 },
      "quiz": { "file": "quiz.html", "title": "进阶测验", "stones": 3 }
    },
    "lab": {
      "key": "lab",
      "name": "代码实验室",
      "scene": "紫峰实验室",
      "ic": "code",
      "color": "var(--cyan)",
      "dir": "code-lab",
      "level": "advanced",
      "lessons": [
        { "file": "lesson-01.html", "title": "变量与数据类型", "stones": 3 },
        { "file": "lesson-02.html", "title": "条件与分支", "stones": 3 },
        { "file": "lesson-03.html", "title": "循环与函数", "stones": 3 },
        { "file": "lesson-04.html", "title": "列表与遍历", "stones": 3 },
        { "file": "lesson-05.html", "title": "字典与字符串", "stones": 3 },
        { "file": "lesson-06.html", "title": "while 与猜数字", "stones": 3 },
        { "file": "lesson-07.html", "title": "综合项目：南京小导游", "stones": 3 }
      ],
      "game": { "file": "game-puzzle.html", "title": "代码谜题闯关", "stones": 3 },
      "quiz": { "file": "quiz.html", "title": "进阶测验", "stones": 3 }
    }
  },
  "badges": [
    { "id": "binary", "name": "花灯密码徽章", "desc": "点亮秦淮花灯，参透 0 和 1 的开关魔法", "ic": "lantern", "module": "binary" },
    { "id": "ai", "name": "AI 训练师徽章", "desc": "在红山动物园教会 AI 认动物，还学会帮它纠错", "ic": "robot", "module": "ai" },
    { "id": "coding", "name": "画舫舵手徽章", "desc": "指挥画舫走出漂亮航线，顺序与循环都难不倒你", "ic": "boat", "module": "coding" },
    { "id": "safety", "name": "城墙卫士徽章", "desc": "守好小秘密、识破坏心思，安全城墙固若金汤", "ic": "wall", "module": "safety" },
    { "id": "terms", "name": "术语研究员徽章", "desc": "解码机器学习、神经网络与大语言模型等主流术语", "ic": "brain", "module": "terms" },
    { "id": "lab", "name": "青年程序员徽章", "desc": "从变量、循环到列表字典，独立完成 Python 小项目", "ic": "code", "module": "lab" }
  ],
  "certificate": {
    "title": "结业证书",
    "subtitle": "「豆苗逐智 · 童享科技」少儿科普课程",
    "text": "小朋友已完成豆苗学堂全部课程学习，授予“科技小苗”称号！",
    "signer": "豆苗学堂 · 豆豆老师",
    "date": "2026 年"
  }
};
